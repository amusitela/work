import Index from './index.vue'

export default Index
