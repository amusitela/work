package com.ruoyi.test.service;

import java.util.List;
import com.ruoyi.test.domain.Goods;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author dingzhen
 * @date 2023-08-22
 */
public interface IGoodsService 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public Goods selectGoodsById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param goods 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<Goods> selectGoodsList(Goods goods);

    /**
     * 新增【请填写功能名称】
     * 
     * @param goods 【请填写功能名称】
     * @return 结果
     */
    public int insertGoods(Goods goods);

    /**
     * 修改【请填写功能名称】
     * 
     * @param goods 【请填写功能名称】
     * @return 结果
     */
    public int updateGoods(Goods goods);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键集合
     * @return 结果
     */
    public int deleteGoodsByIds(Long[] ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteGoodsById(Long id);
}
